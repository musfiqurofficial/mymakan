npx tailwindcss -i ./styles.css -o ./dist/output.css --watch

transition ease-in-out delay-150 duration-300
